from typing import Any, TypedDict


class ResponseType(TypedDict):
    type: str
    value: Any
